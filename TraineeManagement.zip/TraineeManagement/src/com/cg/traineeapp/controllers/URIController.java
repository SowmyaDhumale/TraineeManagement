package com.cg.traineeapp.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.traineeapp.beans.Trainee;

@Controller
public class URIController {

	@RequestMapping(value="/")
	public String getLoginPage() {
		return "loginPage";}

	@RequestMapping(value="/indexPage")
	public String getIndexPage() {
		return "indexPage";}

	@ModelAttribute("trainee")
	public Trainee getTrainee() {
		return new Trainee();
	}

	@RequestMapping(value="/addPage")
	public  String getAddPage() {
		return "addPage";
	}

	@RequestMapping(value="/registrationSuccessPage")
	public  String getRegistrationSuccessPage() {
		return "registrationSuccessPage";
	}

	@RequestMapping(value="/deletePage")
	public  String getDeletePage() {
		return "deletePage";
	}

	@RequestMapping(value="/deleteDisplayPage")
	public  String getDeleteDisplayPage() {
		return "deleteDisplayPage";
	}

	@RequestMapping(value="/modifyPage")
	public  String getModifyPage() {
		return "modifyPage";
	}

	@RequestMapping(value="/updatePage")
	public  String getUpdatePage() {
		return "updatePage";
	}
	@RequestMapping(value="/updateSuccessPage")
	public  String getUpdateSuccessPage() {
		return "updateSuccessPage";
	}

	@RequestMapping(value="/retrievePage")
	public  String getRetrievePage() {
		return "retrievePage";
	}

	@RequestMapping(value="/displayPage")
	public  String getDisplayPage() {
		return "displayPage";
	}

	@RequestMapping(value="/retrieveAllTrainee")
	public  String getAll() {
		return "retrieveAllTrainee";
	}

	@RequestMapping(value="/getAllTraineeList")
	public  String getAll1() {
		return "getAllTraineeList";
	}


}
