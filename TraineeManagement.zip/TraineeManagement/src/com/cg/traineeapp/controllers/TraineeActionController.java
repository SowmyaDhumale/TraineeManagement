package com.cg.traineeapp.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.traineeapp.beans.Trainee;
import com.cg.traineeapp.service.TraineeService;

@Controller
public class TraineeActionController {
	public static int traineeId;
	
	@Autowired
	TraineeService traineeService;
	
	@RequestMapping(value="/loginTrainee")
	public ModelAndView loginTrainee(@RequestParam("userName")String userName, @RequestParam("password")String password) {
		//System.out.println("Hello");
			if(userName.equalsIgnoreCase("admin") && password.equalsIgnoreCase("admin"))
				return new ModelAndView("indexPage");
			
		return new ModelAndView("loginPage");}
		

@RequestMapping(value="/addTrainee")
	public ModelAndView addTrainee(@Valid @ModelAttribute("trainee")Trainee trainee,BindingResult result) {
			if(result.hasErrors())
				return new ModelAndView("addPage");
			trainee=traineeService.addTrainee(trainee);
			System.out.println("Hello");
		return new ModelAndView("registrationSuccessPage", "trainee",trainee);}
	
	@RequestMapping(value="/deleteTrainee")
	public ModelAndView deleteTrainee(@RequestParam("traineeId") int traineeId) {
		Trainee trainee=traineeService.deleteTrainee(traineeId);
		return new ModelAndView("deleteDisplayPage", "trainee", trainee);
	}
	
	@RequestMapping(value="/modifyTrainee")
	public ModelAndView modifyTrainee(@RequestParam("traineeId") int traineeId) {
		Trainee trainee=traineeService.modifyTrainee(traineeId);
		return new ModelAndView("updatePage", "trainee", trainee);
	}
	
	@RequestMapping(value="/updateTrainee")
	public ModelAndView updateTrainee(@RequestParam("traineeId") int traineeId) {
		Trainee trainee=traineeService.updateTrainee(traineeId);
		return new ModelAndView("updateSuccessPage", "trainee", trainee);
	}
	
	@RequestMapping(value="/retrieveTrainee")
	public ModelAndView retrieveTrainee(@RequestParam("traineeId") int traineeId) {
		Trainee trainee=traineeService.retrieveTrainee(traineeId);
		return new ModelAndView("displayPage", "trainee", trainee);
	}

	@RequestMapping(value="/getAll")
	public ModelAndView getAll() {
	ArrayList<Trainee> trainee =traineeService.retrieveAllTrainee(); 
	return  new ModelAndView("getAllTraineeList","trainee",trainee);
	}
}
