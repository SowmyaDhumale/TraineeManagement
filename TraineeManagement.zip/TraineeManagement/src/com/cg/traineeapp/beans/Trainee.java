package com.cg.traineeapp.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="trainee")
public class Trainee {
	@Id
	private int traineeId;
	@NotEmpty
	private String traineeName;
	private String traineeLocation;
	private String traineeDomain;
	
	
	public Trainee() {
		super();
	}


	public Trainee(int traineeId) {
		super();
		this.traineeId = traineeId;
	}


	public Trainee(int traineeId, String traineeName, String traineeLocation, String traineeDomain) {
		super();
		this.traineeId = traineeId;
		this.traineeName = traineeName;
		this.traineeLocation = traineeLocation;
		this.traineeDomain = traineeDomain;
	}
	


	public Trainee(String traineeName, String traineeLocation, String traineeDomain) {
		super();
		this.traineeName = traineeName;
		this.traineeLocation = traineeLocation;
		this.traineeDomain = traineeDomain;
	}


	public int getTraineeId() {
		return traineeId;
	}


	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}


	public String getTraineeName() {
		return traineeName;
	}


	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}


	public String getTraineeLocation() {
		return traineeLocation;
	}


	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}


	public String getTraineeDomain() {
		return traineeDomain;
	}


	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + traineeId;
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Trainee other = (Trainee) obj;
		if (traineeId != other.traineeId)
			return false;
		return true;
	}


	@Override
	public String toString() {
		return "Trainee [traineeId=" + traineeId + ", traineeName=" + traineeName + ", traineeLocation="
				+ traineeLocation + ", traineeDomain=" + traineeDomain + "]";
	}
	
	
	
}
