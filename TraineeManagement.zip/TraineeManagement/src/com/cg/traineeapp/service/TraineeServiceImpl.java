package com.cg.traineeapp.service;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.traineeapp.beans.Trainee;
import com.cg.traineeapp.repo.TraineeRepo;

@Component(value="TraineeService")
public class TraineeServiceImpl implements TraineeService {

	
	@Autowired(required = true)
	private TraineeRepo traineeRepo;
	
	Trainee trainee1;
	@Override
	public Trainee addTrainee(Trainee trainee) {
		traineeRepo.save(trainee);
		return traineeRepo.save(trainee);
	}

	@Override
	public Trainee deleteTrainee(int traineeId) {
		Trainee trainee1 = traineeRepo.findOne(traineeId);
		traineeRepo.delete(traineeId);
		return trainee1;
	}

	@Override
	public Trainee modifyTrainee(int traineeId) {
		//Trainee trainee = traineeRepo.findOne(traineeId);
		Trainee trainee2 = traineeRepo.findOne(traineeId);
		
		return trainee2;
	}
	
	@Override
	public Trainee updateTrainee(int traineeId) {
	
		
		EntityManager entityManager = null;
		Trainee trainee2 =new Trainee();
	
		String str = "update Trainee  set traineeName =: name, traineeLocation=:loc, traineeDomain=:domain where traineeId=:id";
	
		Query query = entityManager.createQuery(str);
		query.setParameter("name",trainee2.getTraineeName());
		query.setParameter("loc",trainee2.getTraineeLocation());
		query.setParameter("domain",trainee2.getTraineeDomain());
		query.setParameter("id",traineeId);
	
		 query.executeUpdate();
	
		return (Trainee) query.getSingleResult();
	}

	@Override
	public Trainee retrieveTrainee(int traineeId) {

		trainee1 = traineeRepo.findOne(traineeId);
		return trainee1;
	}

	@Override
	public ArrayList<Trainee> retrieveAllTrainee() {
		
		return (ArrayList<Trainee>)  traineeRepo.findAll();
	}
	
}
